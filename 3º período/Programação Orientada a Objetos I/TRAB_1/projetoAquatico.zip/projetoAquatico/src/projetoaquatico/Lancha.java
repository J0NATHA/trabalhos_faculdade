package projetoaquatico;

import java.util.Scanner;

public class Lancha extends VeiculoAquaticoColetivo
{
    boolean banheiro;
    
    public Lancha() { }
    
    public Lancha(int numeroPassageiros)
    {
        super(numeroPassageiros);
    }
    
    public Lancha(double preco)
    {
        super(preco);
    }
    
    public Lancha(boolean banheiro)
    {
        setBanheiro(banheiro);
    }
    
    public Lancha(double preco, int numeroPassageiros)
    {
        super(preco, numeroPassageiros);
    }
    
    public Lancha(double preco, int numeroPassageiros, boolean banheiro)
    {
        super(preco, numeroPassageiros);
        setBanheiro(banheiro);
    }
    
    public Lancha(boolean banheiro, String marca, String modelo, int numeroPassageiros)
    {
        super(marca, modelo, numeroPassageiros);
        setBanheiro(banheiro);
    }
    
    public Lancha(String marca, String modelo, double preco, int numeroPassageiros, boolean banheiro)
    {
        super(marca, modelo, preco, numeroPassageiros);
        setBanheiro(banheiro);
    }
    
    public void setBanheiro(boolean banheiro)
    {
        this.banheiro = banheiro;
    }
    
    public boolean getBanheiro()
    {
        return banheiro;
    }
    
    public void imprimir()
    {
        super.imprimir();
        String banheiro = this.banheiro? "sim" : "não";
        System.out.println("Tem banheiro? -> " + banheiro);
    }
    
    public void cadastrar(String marca, String modelo, double preco, int numeroPassageiros, boolean banheiro)
    {
        super.cadastrar(marca, modelo, preco, numeroPassageiros);
        setBanheiro(banheiro);
    }
    
    public void entrada()
    {
        Scanner ent = new Scanner(System.in);
        super.entrada();
        System.out.println("Tem banheiro? 1 - Sim, 2 - Não ");
        setBanheiro(Integer.parseInt(ent.nextLine()) == 1);
    }
}
