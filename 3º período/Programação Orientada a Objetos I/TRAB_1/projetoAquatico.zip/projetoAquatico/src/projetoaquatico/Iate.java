package projetoaquatico;

import java.util.Scanner;

public class Iate extends VeiculoAquaticoColetivo
{
    int numeroTripulantes;
    
    public Iate() { } 
    
    public Iate(int numeroTripulantes)
    {
        setNumeroTripulantes(numeroTripulantes);
    }
    
    public Iate(double preco, int numeroTripulantes)
    {
        super(preco);
        setNumeroTripulantes(numeroTripulantes);
    }
    
    public Iate(double preco, int numeroPassageiros, int numeroTripulantes)
    {
        super(preco, numeroPassageiros);
        setNumeroTripulantes(numeroTripulantes);
    }
    
    public Iate(String marca, double preco, int numeroPassageiros)
    {
        super(marca, preco, numeroPassageiros);
    }
    
    public Iate(String marca, double preco, int numeroPassageiros, int numeroTripulantes)
    {
        super(marca, preco, numeroPassageiros);
        setNumeroTripulantes(numeroTripulantes);
    }
    
    public Iate(String marca, String modelo, int numeroPassageiros, int numeroTripulantes)
    {
        super(marca, modelo, numeroPassageiros);
        setNumeroTripulantes(numeroTripulantes);
    }
    
    public Iate(String marca, String modelo, double preco, int numeroPassageiros, int numeroTripulantes)
    {
        super(marca, modelo, preco, numeroPassageiros);
        setNumeroTripulantes(numeroTripulantes);
    }
    
    public void setNumeroTripulantes(int numeroTripulantes)
    {
        if (numeroTripulantes > 0)
        {
            this.numeroTripulantes = numeroTripulantes;
        }
    }
    
    public int getNumeroTripulantes()
    {
        return numeroTripulantes;
    }
    
    public void imprimir()
    {
        super.imprimir();
        System.out.println("Número de tripulantes -> " + getNumeroTripulantes());
    }
    
    public void cadastrar(String marca, String modelo, double preco, int numeroPassageiros, int numeroTripulantes)
    {
        super.cadastrar(marca, modelo, preco, numeroPassageiros);
        setNumeroTripulantes(numeroTripulantes);
    }
    
    public void entrada()
    {
        Scanner ent = new Scanner(System.in);
        super.entrada();
        System.out.print("Número de tripulantes -> ");
        setNumeroTripulantes(Integer.parseInt(ent.nextLine()));
    }
}
