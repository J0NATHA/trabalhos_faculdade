package projetoaquatico;

import java.util.Scanner;

public class VeiculoAquaticoColetivo extends VeiculoAquatico
{
    int numeroPassageiros;
    
    public VeiculoAquaticoColetivo() { }
    
    public VeiculoAquaticoColetivo(int numeroPassageiros)
    {
        setNumeroPassageiros(numeroPassageiros);
    }
    
    public VeiculoAquaticoColetivo(double preco)
    {
        super(preco);
    }
    
    public VeiculoAquaticoColetivo(double preco, int numeroPassageiros)
    {
        super(preco);
        setNumeroPassageiros(numeroPassageiros);
    }
    
    public VeiculoAquaticoColetivo(double preco, String modelo, int numeroPassageiros)
    {
        super(preco, modelo);
        setNumeroPassageiros(numeroPassageiros);
    }
    
    public VeiculoAquaticoColetivo(String marca, String modelo, int numeroPassageiros)
    {
        super(marca, modelo);
        setNumeroPassageiros(numeroPassageiros);
    }
    
    public VeiculoAquaticoColetivo(String marca, double preco, int numeroPassageiros)
    {
        super(marca, preco);
        setNumeroPassageiros(numeroPassageiros);
    }
    
    public VeiculoAquaticoColetivo(String marca, String modelo, double preco, int numeroPassageiros)
    {
        super(marca, modelo, preco);
        setNumeroPassageiros(numeroPassageiros);
    }
    
    public void setNumeroPassageiros(int numeroPassageiros)
    {
        if (numeroPassageiros > 0)
        {
            this.numeroPassageiros = numeroPassageiros;
        }
    }
    
    public int getNumeroPassageiros()
    {
        return numeroPassageiros;
    }
    
    public void imprimir()
    {
        super.imprimir();
        System.out.println("Número de passageiros -> " + getNumeroPassageiros());
    }
    
    public void cadastrar(String marca, String modelo, double preco, int numeroPassageiros)
    {
        super.cadastrar(marca, modelo, preco);
        setNumeroPassageiros(numeroPassageiros);
    }
    
    public void entrada()
    {
        Scanner ent = new Scanner(System.in);
        super.entrada();
        System.out.print("Número de passageiros -> ");
        setNumeroPassageiros(Integer.parseInt(ent.nextLine()));
    }
}
