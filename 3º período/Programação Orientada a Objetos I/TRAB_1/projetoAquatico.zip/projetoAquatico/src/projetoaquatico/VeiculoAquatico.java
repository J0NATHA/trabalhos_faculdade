package projetoaquatico;

import java.util.Scanner;

public class VeiculoAquatico
{
    String marca, modelo;
    double preco;
    
    public VeiculoAquatico() { }
    
    public VeiculoAquatico(String marca)
    {
        setMarca(marca);
    }
    
    public VeiculoAquatico(double preco)
    {
        setPreco(preco);
    }
    
    public VeiculoAquatico(String marca, double preco)
    {
        setMarca(marca);
        setPreco(preco);
    }
    
    public VeiculoAquatico(String marca, String modelo)
    {
        setMarca(marca);
        setModelo(modelo);
    }
    
    public VeiculoAquatico(double preco, String modelo)
    {
        setPreco(preco);
        setModelo(modelo);
    }
    
    public VeiculoAquatico(double preco, String modelo, String marca)
    {
        setPreco(preco);
        setModelo(modelo);
        setMarca(marca);
    }
    
    public VeiculoAquatico(String marca, String modelo, double preco)
    {
        setMarca(marca);
        setModelo(modelo);
        setPreco(preco);
    }
    
    public void setMarca(String marca)
    {
        if (!marca.isEmpty())
        {
            this.marca = marca;
        }
    }
    
    public void setModelo(String modelo)
    {
        if (!modelo.isEmpty())
        {
            this.modelo = modelo;
        }
    }
    
    public void setPreco(double preco)
    {
        if (preco > 0.0)
        {
            this.preco = preco;
        }
    }
    
    public String getMarca()
    {
        return marca;
    }
    
    public String getModelo()
    {
        return modelo;
    }
    
    public double getPreco()
    {
        return preco;
    }
    
    public void imprimir()
    {
        System.out.println("Marca -> " + getMarca()); 
        System.out.println("Modelo -> " + getModelo()); 
        System.out.println("Preço -> " + getPreco());
    }
    
    public void cadastrar(String marca, String modelo, double preco)
    {
        setMarca(marca);
        setModelo(modelo);
        setPreco(preco);
    }
    
    public void entrada()
    {
        Scanner ent = new Scanner(System.in);
        System.out.print("Marca -> ");
        setMarca(ent.nextLine());
        System.out.print("Modelo -> ");
        setModelo(ent.nextLine());
        System.out.print("Preço -> ");
        setPreco(Double.parseDouble(ent.nextLine()));
    }
}
