package projetoaquatico;

import java.util.Scanner;

public class JetSki extends VeiculoAquatico
{
    String tipoCasco;
    
    public JetSki() { }
    
    public JetSki(String marca)
    {
        super(marca);
    }
    
    public JetSki(String marca, double preco)
    {
        super(marca, preco);
    }
    
    public JetSki(String marca, double preco, String tipoCasco)
    {
        super(marca, preco);
        setTipoCasco(tipoCasco);
    }
    
    public JetSki(double preco)
    {
        super(preco);
    }
    
    public JetSki(String marca, String tipoCasco)
    {
        super(marca);
        setTipoCasco(tipoCasco);
    }
    
    public JetSki(String marca, String modelo, String tipoCasco)
    {
        super(marca, modelo);
        setTipoCasco(tipoCasco);
    }
    
    public JetSki(String marca, String modelo, double preco, String tipoCasco)
    {
        super(marca, modelo, preco);
        setTipoCasco(tipoCasco);
    }
    
    public void setTipoCasco(String tipoCasco)
    {
        if (!tipoCasco.isEmpty())
        {
            this.tipoCasco = tipoCasco;
        }
    }
    
    public String getTipoCasco()
    {
        return tipoCasco;
    }
    
    public void imprimir()
    {
        super.imprimir();
        System.out.println("Tipo do casco -> " + getTipoCasco());
    }
    
    public void cadastrar(String marca, String modelo, double preco, String tipoCasco)
    {
        super.cadastrar(marca, modelo, preco);
        setTipoCasco(tipoCasco);
    }
    
    public void entrada()
    {
        Scanner ent = new Scanner(System.in);
        super.entrada();
        System.out.print("Tipo do casco -> ");
        setTipoCasco(ent.nextLine());
    }
}
