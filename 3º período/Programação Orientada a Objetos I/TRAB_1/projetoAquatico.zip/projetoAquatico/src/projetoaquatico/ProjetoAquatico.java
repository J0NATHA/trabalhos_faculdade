package projetoaquatico;

public class ProjetoAquatico
{
    public static void main(String[] args)
    {
        JetSki jet1 = new JetSki();
        JetSki jet2 = new JetSki(2000);
        JetSki jet3 = new JetSki("Honda", "Crock", 25000.30, "Tipo 1");
        
        jet1.cadastrar("Hugo", "Apache", 30000, "Tipo 2");
        jet2.setMarca("JetEsqui");
        jet2.setModelo("Iron");
        jet2.setTipoCasco("Tipo 3");
        
        Lancha lan1 = new Lancha();
        Lancha lan2 = new Lancha(true);
        Lancha lan3 = new Lancha("Lego", "Mod", 2320.5, 20, true);
        
        lan1.cadastrar("Raluca", "Print", 100000, 4, false);
        lan2.setMarca("Mark");
        lan2.setModelo("Muerto");
        lan2.setNumeroPassageiros(11);
        lan2.setPreco(200000);
        
        Iate iat1 = new Iate();
        Iate iat2 = new Iate(21000.4, 3);
        Iate iat3 = new Iate("EA", "Ravenclaw", 350000, 10, 5);
        
        iat1.cadastrar("Lenovo", "PR0", 14000, 13, 4);
        iat2.setMarca("Nova");
        iat2.setModelo("MKIII");
        iat2.setNumeroPassageiros(9);
        
        System.out.println("\n=== JetSkis ===");
        jet1.imprimir();
        System.out.print("\n");
        jet2.imprimir();
        System.out.print("\n");
        jet3.imprimir();
        
        System.out.println("\n=== Lanchas ===");
        lan1.imprimir();
        System.out.print("\n");
        lan2.imprimir();
        System.out.print("\n");
        lan3.imprimir();
        
        System.out.println("\n=== Iates ===");
        iat1.imprimir();
        System.out.print("\n");
        iat2.imprimir();
        System.out.print("\n");
        iat3.imprimir();
    }
    
}
